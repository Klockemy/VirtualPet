﻿using System;

namespace VirtualPet
{
    public class Pet
    {
        public int age = 0;
        public int happy = 10;
        public int hungry = 10;
        public string name;

        public void talk()
        {
        } // end talk method

        public void eat()
        {
            hungry += 4;
        } // end eat method

        public void play()
        {
            happy += 3;
        } // end play method
    } // end Pet class
} // end namespace
