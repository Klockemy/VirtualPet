﻿using System;
using System.Text;
using System.IO;

namespace VirtualPet
{
    public class Save
    {
        public static Pet myPet = new Pet();

        public void MakeSave()
        {
            string[] data = new string[]{myPet.name, Convert.ToString(myPet.age),  Convert.ToString(myPet.hungry), Convert.ToString(myPet.happy) };
            foreach (string s in data)
            {
                Console.WriteLine(s);
            } // end foreach
            Console.ReadLine();
        } // end makesave method

        public void LoadSave()
        {

        } // end loadsave method
    } // end save class
} // end namespace
